import { useEffect, useRef } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { 
  Lightbulb, 
  Server, 
  Workflow, 
  Bot, 
  Plug, 
  Settings,
  ArrowRight 
} from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

const services = [
  {
    icon: Lightbulb,
    title: 'AI Strategy & Consulting',
    description: 'AI readiness assessment, ROI planning, automation roadmaps, priority use-cases that deliver measurable outcomes.',
    features: ['ROI Analysis', 'Use-case Prioritization', 'Technology Roadmap']
  },
  {
    icon: Server,
    title: 'AI Infrastructure & Architecture',
    description: 'Robust architecture including APIs, vector stores, secure cloud deployment, and integrations with core business systems.',
    features: ['Cloud Deployment', 'Vector Databases', 'API Architecture']
  },
  {
    icon: Workflow,
    title: 'Automation Design & Deployment',
    description: 'End-to-end workflow automation — sales, support, ops, data pipelines, reporting and alerting systems.',
    features: ['Workflow Design', 'Pipeline Automation', 'Alert Systems']
  },
  {
    icon: Bot,
    title: 'Custom AI Agents',
    description: 'Autonomous agents that perform tasks including lead qualification, reporting, workflow execution, customer support triggers, content operations.',
    features: ['Lead Qualification', 'Report Generation', 'Task Automation']
  },
  {
    icon: Plug,
    title: 'Integration Services',
    description: 'Seamless integration of AI systems with existing CRM, ERP, databases, internal tools and third-party APIs.',
    features: ['CRM Integration', 'ERP Connectors', 'API Middleware']
  },
  {
    icon: Settings,
    title: 'Ongoing Optimization & Support',
    description: 'Continuous improvement, monitoring, scaling, and governance of deployed AI systems.',
    features: ['Performance Monitoring', 'Model Refinement', '24/7 Support']
  }
];

const Services = () => {
  const sectionRef = useRef<HTMLElement>(null);
  const headingRef = useRef<HTMLDivElement>(null);
  const cardsRef = useRef<(HTMLDivElement | null)[]>([]);

  useEffect(() => {
    const ctx = gsap.context(() => {
      gsap.fromTo(headingRef.current,
        { opacity: 0, y: 30 },
        {
          opacity: 1,
          y: 0,
          duration: 0.6,
          scrollTrigger: {
            trigger: headingRef.current,
            start: 'top 80%',
            toggleActions: 'play none none reverse'
          }
        }
      );

      cardsRef.current.forEach((card, i) => {
        if (card) {
          gsap.fromTo(card,
            { opacity: 0, y: 40 },
            {
              opacity: 1,
              y: 0,
              duration: 0.5,
              delay: i * 0.08,
              scrollTrigger: {
                trigger: card,
                start: 'top 85%',
                toggleActions: 'play none none reverse'
              }
            }
          );
        }
      });
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  return (
    <section
      ref={sectionRef}
      id="services"
      className="py-20 lg:py-32 bg-[#FAFBFC]"
    >
      <div className="section-padding">
        <div ref={headingRef} className="text-center max-w-3xl mx-auto mb-16">
          <span className="label-mono text-blue-600 mb-4 block">Our Services</span>
          <h2 className="text-3xl lg:text-5xl font-bold text-slate-900 mb-4">
            Full-Stack AI Infrastructure & Automation
          </h2>
          <p className="text-lg text-slate-600">
            From strategy to deployment to ongoing optimization — we handle the entire AI lifecycle.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-7xl mx-auto">
          {services.map((service, i) => (
            <div
              key={service.title}
              ref={el => { cardsRef.current[i] = el; }}
              className="group bg-white rounded-2xl p-6 lg:p-8 border border-slate-100 shadow-sm card-hover cursor-pointer"
            >
              <div className="w-12 h-12 rounded-xl bg-blue-50 flex items-center justify-center mb-5 group-hover:bg-blue-600 transition-colors duration-300">
                <service.icon className="w-6 h-6 text-blue-600 group-hover:text-white transition-colors duration-300" />
              </div>
              
              <h3 className="text-xl font-bold text-slate-900 mb-3">
                {service.title}
              </h3>
              
              <p className="text-slate-600 text-sm leading-relaxed mb-4">
                {service.description}
              </p>

              <div className="flex flex-wrap gap-2 mb-4">
                {service.features.map((feature) => (
                  <span
                    key={feature}
                    className="text-xs font-medium text-slate-500 bg-slate-100 px-2 py-1 rounded-md"
                  >
                    {feature}
                  </span>
                ))}
              </div>

              <div className="flex items-center text-blue-600 font-medium text-sm group-hover:gap-3 gap-2 transition-all">
                Learn more
                <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Services;
