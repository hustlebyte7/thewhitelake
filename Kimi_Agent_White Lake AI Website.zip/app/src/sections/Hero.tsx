import { useEffect, useRef } from 'react';
import { gsap } from 'gsap';
import { ArrowRight, Play, Building2, Cpu, BarChart3, Shield } from 'lucide-react';

const Hero = () => {
  const heroRef = useRef<HTMLElement>(null);
  const headlineRef = useRef<HTMLHeadingElement>(null);
  const subheadlineRef = useRef<HTMLParagraphElement>(null);
  const ctaRef = useRef<HTMLDivElement>(null);
  const visualRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      const tl = gsap.timeline({ defaults: { ease: 'power3.out' } });

      // Headline animation - word by word
      const words = headlineRef.current?.querySelectorAll('.word');
      if (words) {
        tl.fromTo(words,
          { opacity: 0, y: 30 },
          { opacity: 1, y: 0, duration: 0.6, stagger: 0.08 },
          0.2
        );
      }

      tl.fromTo(subheadlineRef.current,
        { opacity: 0, y: 20 },
        { opacity: 1, y: 0, duration: 0.6 },
        0.6
      );

      tl.fromTo(ctaRef.current,
        { opacity: 0, y: 20 },
        { opacity: 1, y: 0, duration: 0.5 },
        0.8
      );

      tl.fromTo(visualRef.current,
        { opacity: 0, scale: 0.95 },
        { opacity: 1, scale: 1, duration: 0.8 },
        0.4
      );
    }, heroRef);

    return () => ctx.revert();
  }, []);

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section
      ref={heroRef}
      className="relative min-h-screen flex items-center pt-20 lg:pt-0 overflow-hidden"
    >
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-30">
        <div className="absolute inset-0" style={{
          backgroundImage: `radial-gradient(circle at 1px 1px, #cbd5e1 1px, transparent 0)`,
          backgroundSize: '40px 40px'
        }} />
      </div>

      {/* Gradient Blob */}
      <div className="absolute top-1/4 right-0 w-[600px] h-[600px] bg-blue-100 rounded-full blur-3xl opacity-40 -translate-y-1/2" />

      <div className="section-padding w-full relative z-10">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-16 items-center max-w-7xl mx-auto">
          {/* Left Content */}
          <div className="order-2 lg:order-1">
            <h1
              ref={headlineRef}
              className="text-4xl sm:text-5xl lg:text-6xl xl:text-7xl font-extrabold text-slate-900 leading-[1.1] mb-6"
            >
              <span className="word inline-block">AI</span>{' '}
              <span className="word inline-block">Built</span>{' '}
              <span className="word inline-block">to</span>{' '}
              <span className="word inline-block">Work,</span>
              <br />
              <span className="word inline-block text-blue-600">Not</span>{' '}
              <span className="word inline-block text-blue-600">Just</span>{' '}
              <span className="word inline-block text-blue-600">Talk</span>
            </h1>

            <p
              ref={subheadlineRef}
              className="text-lg lg:text-xl text-slate-600 leading-relaxed mb-8 max-w-xl"
            >
              We design and implement full AI infrastructure, intelligent automations, 
              and strategic systems that replace manual workflows, reduce costs, and scale operations.
            </p>

            <div ref={ctaRef} className="flex flex-col sm:flex-row gap-4 mb-12">
              <button
                onClick={() => scrollToSection('contact')}
                className="btn-primary group"
              >
                Book a Free AI Strategy Session
                <ArrowRight className="w-4 h-4 ml-2 group-hover:translate-x-1 transition-transform" />
              </button>
              <button
                onClick={() => scrollToSection('how-it-works')}
                className="btn-secondary"
              >
                <Play className="w-4 h-4 mr-2" />
                See How It Works
              </button>
            </div>

            {/* Trust Bar */}
            <div className="border-t border-slate-200 pt-6">
              <p className="label-mono mb-4">Trusted by 50+ companies</p>
              <div className="flex flex-wrap items-center gap-6 opacity-60">
                <div className="flex items-center gap-2">
                  <Building2 className="w-5 h-5" />
                  <span className="text-sm font-medium">Enterprise</span>
                </div>
                <div className="flex items-center gap-2">
                  <Cpu className="w-5 h-5" />
                  <span className="text-sm font-medium">Tech</span>
                </div>
                <div className="flex items-center gap-2">
                  <BarChart3 className="w-5 h-5" />
                  <span className="text-sm font-medium">Finance</span>
                </div>
                <div className="flex items-center gap-2">
                  <Shield className="w-5 h-5" />
                  <span className="text-sm font-medium">Healthcare</span>
                </div>
              </div>
            </div>
          </div>

          {/* Right Visual */}
          <div ref={visualRef} className="order-1 lg:order-2 relative">
            <div className="relative rounded-2xl overflow-hidden shadow-2xl shadow-blue-900/10">
              <img
                src="/hero_ai_visual.jpg"
                alt="AI Infrastructure Visualization"
                className="w-full h-auto"
              />
              {/* Overlay Stats */}
              <div className="absolute bottom-4 left-4 right-4 grid grid-cols-3 gap-2">
                <div className="bg-white/95 backdrop-blur-sm rounded-lg p-3 text-center">
                  <p className="text-2xl font-bold text-blue-600">$2.4M</p>
                  <p className="text-xs text-slate-500">Cost Saved</p>
                </div>
                <div className="bg-white/95 backdrop-blur-sm rounded-lg p-3 text-center">
                  <p className="text-2xl font-bold text-emerald-600">50+</p>
                  <p className="text-xs text-slate-500">Systems Deployed</p>
                </div>
                <div className="bg-white/95 backdrop-blur-sm rounded-lg p-3 text-center">
                  <p className="text-2xl font-bold text-slate-900">24/7</p>
                  <p className="text-xs text-slate-500">Automation</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;
