import { useEffect, useRef } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

const expertise = [
  'LLM Architecture',
  'Vector Databases',
  'API Design',
  'Cloud Infrastructure',
  'Workflow Automation',
  'Enterprise Integrations'
];

const About = () => {
  const sectionRef = useRef<HTMLElement>(null);
  const contentRef = useRef<HTMLDivElement>(null);
  const imageRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      gsap.fromTo(imageRef.current,
        { opacity: 0, x: -50 },
        {
          opacity: 1,
          x: 0,
          duration: 0.8,
          scrollTrigger: {
            trigger: sectionRef.current,
            start: 'top 70%',
            toggleActions: 'play none none reverse'
          }
        }
      );

      gsap.fromTo(contentRef.current,
        { opacity: 0, x: 50 },
        {
          opacity: 1,
          x: 0,
          duration: 0.8,
          delay: 0.2,
          scrollTrigger: {
            trigger: sectionRef.current,
            start: 'top 70%',
            toggleActions: 'play none none reverse'
          }
        }
      );

      // Animate expertise tags
      const tags = contentRef.current?.querySelectorAll('.expertise-tag');
      tags?.forEach((tag, i) => {
        gsap.fromTo(tag,
          { opacity: 0, scale: 0.9 },
          {
            opacity: 1,
            scale: 1,
            duration: 0.4,
            delay: 0.5 + i * 0.08,
            scrollTrigger: {
              trigger: contentRef.current,
              start: 'top 70%',
              toggleActions: 'play none none reverse'
            }
          }
        );
      });
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  return (
    <section
      ref={sectionRef}
      id="about"
      className="py-20 lg:py-32 bg-white"
    >
      <div className="section-padding">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-20 items-center max-w-7xl mx-auto">
          {/* Image */}
          <div ref={imageRef} className="relative">
            <div className="rounded-2xl overflow-hidden shadow-xl">
              <img
                src="/about_team.jpg"
                alt="The White Lake Team"
                className="w-full h-auto"
              />
            </div>
            {/* Floating badge */}
            <div className="absolute -bottom-6 -right-6 bg-blue-600 text-white rounded-2xl p-6 shadow-xl">
              <p className="text-3xl font-bold">8+</p>
              <p className="text-sm text-blue-100">Years Experience</p>
            </div>
          </div>

          {/* Content */}
          <div ref={contentRef}>
            <span className="label-mono text-blue-600 mb-4 block">About Us</span>
            <h2 className="text-3xl lg:text-5xl font-bold text-slate-900 mb-6">
              Built by Engineers,<br />
              <span className="text-blue-600">Led by Outcomes</span>
            </h2>

            <p className="text-lg text-slate-600 leading-relaxed mb-6">
              We're a team of AI engineers, solution architects, and automation specialists 
              who've deployed systems for Fortune 500s and high-growth startups alike.
            </p>

            <p className="text-slate-600 leading-relaxed mb-8">
              We don't do demos — we do production systems that run your business. 
              Every project starts with understanding your pain points and ends with 
              measurable business outcomes.
            </p>

            {/* Expertise Tags */}
            <div>
              <p className="label-mono text-slate-500 mb-4">Our Expertise</p>
              <div className="flex flex-wrap gap-2">
                {expertise.map((skill) => (
                  <span
                    key={skill}
                    className="expertise-tag px-4 py-2 bg-slate-100 text-slate-700 rounded-full text-sm font-medium hover:bg-blue-50 hover:text-blue-600 transition-colors cursor-default"
                  >
                    {skill}
                  </span>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;
