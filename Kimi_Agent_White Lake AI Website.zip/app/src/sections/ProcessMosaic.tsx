import { useRef, useLayoutEffect } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

const ProcessMosaic = () => {
  const sectionRef = useRef<HTMLElement>(null);
  const titleCardRef = useRef<HTMLDivElement>(null);
  const portraitCardRef = useRef<HTMLDivElement>(null);
  const buildingCardRef = useRef<HTMLDivElement>(null);
  const studioCardRef = useRef<HTMLDivElement>(null);
  const textCardRef = useRef<HTMLDivElement>(null);
  const blueRuleRef = useRef<HTMLDivElement>(null);

  useLayoutEffect(() => {
    const ctx = gsap.context(() => {
      const scrollTl = gsap.timeline({
        scrollTrigger: {
          trigger: sectionRef.current,
          start: 'top top',
          end: '+=130%',
          pin: true,
          scrub: 0.6,
        }
      });

      // ENTRANCE (0% - 30%)
      scrollTl.fromTo(titleCardRef.current,
        { x: '-50vw', opacity: 0 },
        { x: 0, opacity: 1, ease: 'none' },
        0
      );

      scrollTl.fromTo(portraitCardRef.current,
        { y: '-35vh', opacity: 0 },
        { y: 0, opacity: 1, ease: 'none' },
        0.06
      );

      scrollTl.fromTo(buildingCardRef.current,
        { x: '50vw', opacity: 0 },
        { x: 0, opacity: 1, ease: 'none' },
        0.08
      );

      scrollTl.fromTo(studioCardRef.current,
        { x: '-60vw', opacity: 0 },
        { x: 0, opacity: 1, ease: 'none' },
        0.10
      );

      scrollTl.fromTo(textCardRef.current,
        { x: '55vw', opacity: 0 },
        { x: 0, opacity: 1, ease: 'none' },
        0.12
      );

      // Blue rule scale
      scrollTl.fromTo(blueRuleRef.current,
        { scaleX: 0 },
        { scaleX: 1, ease: 'none' },
        0.18
      );

      // SETTLE (30% - 70%): Parallax
      const images = sectionRef.current?.querySelectorAll('.parallax-image');
      images?.forEach((img) => {
        scrollTl.fromTo(img,
          { y: 0 },
          { y: '-1vh', ease: 'none' },
          0.30
        );
      });

      // EXIT (70% - 100%)
      scrollTl.fromTo(studioCardRef.current,
        { x: 0, opacity: 1 },
        { x: '-55vw', opacity: 0, ease: 'power2.in' },
        0.70
      );

      scrollTl.fromTo(textCardRef.current,
        { x: 0, opacity: 1 },
        { x: '55vw', opacity: 0, ease: 'power2.in' },
        0.70
      );

      scrollTl.fromTo([titleCardRef.current, portraitCardRef.current, buildingCardRef.current],
        { y: 0, opacity: 1 },
        { y: '-18vh', opacity: 0, ease: 'power2.in', stagger: 0.02 },
        0.72
      );

    }, sectionRef);

    return () => ctx.revert();
  }, []);

  return (
    <section
      ref={sectionRef}
      className="section-pinned bg-[#F4F6F8] z-40"
    >
      <div className="w-full h-full relative px-[6vw] py-[10vh]">
        {/* Top Row */}
        {/* Title Card */}
        <div
          ref={titleCardRef}
          className="absolute left-[6vw] top-[10vh] w-[34vw] h-[22vh] text-card flex flex-col justify-center px-8"
        >
          <h2 className="text-4xl lg:text-5xl text-[#0B0D10] mb-2">Process</h2>
          <p className="text-[#6B7280] text-sm">Discover → Define → Design → Deliver.</p>
        </div>

        {/* Portrait Card */}
        <div
          ref={portraitCardRef}
          className="absolute left-[42vw] top-[10vh] w-[26vw] h-[22vh] image-card"
        >
          <img
            src="/studio_portrait_closeup.jpg"
            alt="Process portrait"
            className="parallax-image w-full h-full object-cover scale-110"
          />
        </div>

        {/* Building Card */}
        <div
          ref={buildingCardRef}
          className="absolute left-[70vw] top-[10vh] w-[24vw] h-[22vh] image-card"
        >
          <img
            src="/studio_building_exterior.jpg"
            alt="Process building"
            className="parallax-image w-full h-full object-cover scale-110"
          />
        </div>

        {/* Bottom Row */}
        {/* Large Studio Card */}
        <div
          ref={studioCardRef}
          className="absolute left-[6vw] top-[36vh] w-[62vw] h-[54vh] image-card"
        >
          <img
            src="/studio_interior_wide.jpg"
            alt="Process studio"
            className="parallax-image w-full h-full object-cover scale-110"
          />
        </div>

        {/* Text Card */}
        <div
          ref={textCardRef}
          className="absolute left-[70vw] top-[36vh] w-[24vw] h-[54vh] text-card flex flex-col justify-between p-6"
        >
          <div>
            <p className="text-[#0B0D10] text-sm leading-relaxed mb-6">
              We start with listening, then build systems that scale—without losing soul.
            </p>
            {/* Blue Rule */}
            <div
              ref={blueRuleRef}
              className="w-[40%] h-[2px] bg-[#2F6BFF] origin-left"
            />
          </div>
          <a
            href="#case"
            className="text-[#2F6BFF] text-sm font-medium hover:underline flex items-center gap-2"
          >
            See a case study
            <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 8l4 4m0 0l-4 4m4-4H3" />
            </svg>
          </a>
        </div>
      </div>
    </section>
  );
};

export default ProcessMosaic;
