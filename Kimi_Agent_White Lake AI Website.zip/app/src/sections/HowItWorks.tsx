import { useEffect, useRef } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Search, PenTool, Rocket, TrendingUp } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

const steps = [
  {
    number: '01',
    icon: Search,
    title: 'Discover',
    description: 'We audit your current systems, identify automation opportunities, and prioritize use-cases by ROI.',
    details: ['System Audit', 'Pain Point Analysis', 'ROI Projection']
  },
  {
    number: '02',
    icon: PenTool,
    title: 'Design',
    description: 'We architect the solution, select the right AI models, and plan integrations with your existing stack.',
    details: ['Architecture Design', 'Model Selection', 'Integration Planning']
  },
  {
    number: '03',
    icon: Rocket,
    title: 'Deploy',
    description: 'We build, test, and launch your AI systems with minimal disruption to operations.',
    details: ['Development', 'Testing', 'Production Launch']
  },
  {
    number: '04',
    icon: TrendingUp,
    title: 'Optimize',
    description: 'We monitor performance, refine models, and scale as your needs evolve.',
    details: ['Performance Monitoring', 'Model Refinement', 'Continuous Improvement']
  }
];

const HowItWorks = () => {
  const sectionRef = useRef<HTMLElement>(null);
  const headingRef = useRef<HTMLDivElement>(null);
  const timelineRef = useRef<HTMLDivElement>(null);
  const lineRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      gsap.fromTo(headingRef.current,
        { opacity: 0, y: 30 },
        {
          opacity: 1,
          y: 0,
          duration: 0.6,
          scrollTrigger: {
            trigger: headingRef.current,
            start: 'top 80%',
            toggleActions: 'play none none reverse'
          }
        }
      );

      // Animate timeline line
      if (lineRef.current) {
        gsap.fromTo(lineRef.current,
          { scaleX: 0 },
          {
            scaleX: 1,
            duration: 1.5,
            ease: 'power2.out',
            scrollTrigger: {
              trigger: timelineRef.current,
              start: 'top 70%',
              toggleActions: 'play none none reverse'
            }
          }
        );
      }

      // Animate steps
      const stepCards = timelineRef.current?.querySelectorAll('.step-card');
      stepCards?.forEach((card, i) => {
        gsap.fromTo(card,
          { opacity: 0, y: 40 },
          {
            opacity: 1,
            y: 0,
            duration: 0.6,
            delay: i * 0.2,
            scrollTrigger: {
              trigger: timelineRef.current,
              start: 'top 65%',
              toggleActions: 'play none none reverse'
            }
          }
        );
      });
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  return (
    <section
      ref={sectionRef}
      id="how-it-works"
      className="py-20 lg:py-32 bg-white"
    >
      <div className="section-padding">
        <div ref={headingRef} className="text-center max-w-3xl mx-auto mb-16">
          <span className="label-mono text-blue-600 mb-4 block">Our Process</span>
          <h2 className="text-3xl lg:text-5xl font-bold text-slate-900 mb-4">
            How We Work
          </h2>
          <p className="text-lg text-slate-600">
            A proven four-step process from discovery to optimization.
          </p>
        </div>

        <div ref={timelineRef} className="relative max-w-6xl mx-auto">
          {/* Timeline Line (Desktop) */}
          <div
            ref={lineRef}
            className="hidden lg:block absolute top-24 left-0 right-0 h-0.5 bg-gradient-to-r from-blue-600 via-blue-400 to-blue-600 origin-left"
          />

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {steps.map((step) => (
              <div key={step.number} className="step-card relative">
                {/* Number Circle */}
                <div className="relative z-10 w-12 h-12 rounded-full bg-blue-600 flex items-center justify-center mb-6 shadow-lg shadow-blue-600/25">
                  <span className="text-white font-bold text-sm">{step.number}</span>
                </div>

                {/* Content Card */}
                <div className="bg-slate-50 rounded-2xl p-6 border border-slate-100 h-full">
                  <div className="w-10 h-10 rounded-lg bg-blue-100 flex items-center justify-center mb-4">
                    <step.icon className="w-5 h-5 text-blue-600" />
                  </div>

                  <h3 className="text-xl font-bold text-slate-900 mb-3">
                    {step.title}
                  </h3>

                  <p className="text-slate-600 text-sm leading-relaxed mb-4">
                    {step.description}
                  </p>

                  <ul className="space-y-2">
                    {step.details.map((detail) => (
                      <li key={detail} className="flex items-center gap-2 text-sm text-slate-500">
                        <span className="w-1.5 h-1.5 rounded-full bg-blue-400" />
                        {detail}
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default HowItWorks;
