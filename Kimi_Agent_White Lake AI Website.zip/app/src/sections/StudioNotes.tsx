import { useRef, useLayoutEffect } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

const notes = [
  { title: 'On restraint', category: 'Essay', image: '/notes_essay_image.jpg' },
  { title: 'Designing for print in a screen-first world', category: 'Process', image: '/notes_process_image.jpg' },
  { title: 'How we build a creative brief', category: 'Studio', image: '/notes_studio_image.jpg' },
];

const StudioNotes = () => {
  const sectionRef = useRef<HTMLElement>(null);
  const leftCardRef = useRef<HTMLDivElement>(null);
  const topRightCardRef = useRef<HTMLDivElement>(null);
  const bottomRightCardRef = useRef<HTMLDivElement>(null);

  useLayoutEffect(() => {
    const ctx = gsap.context(() => {
      const scrollTl = gsap.timeline({
        scrollTrigger: {
          trigger: sectionRef.current,
          start: 'top top',
          end: '+=140%',
          pin: true,
          scrub: 0.6,
        }
      });

      // ENTRANCE (0% - 30%)
      scrollTl.fromTo(leftCardRef.current,
        { x: '-70vw', opacity: 0, rotateY: 8 },
        { x: 0, opacity: 1, rotateY: 0, ease: 'none' },
        0
      );

      scrollTl.fromTo(topRightCardRef.current,
        { x: '60vw', y: '-20vh', opacity: 0 },
        { x: 0, y: 0, opacity: 1, ease: 'none' },
        0.08
      );

      scrollTl.fromTo(bottomRightCardRef.current,
        { x: '60vw', y: '30vh', opacity: 0 },
        { x: 0, y: 0, opacity: 1, ease: 'none' },
        0.12
      );

      // Labels stagger
      const labels = sectionRef.current?.querySelectorAll('.note-label');
      labels?.forEach((label, i) => {
        scrollTl.fromTo(label,
          { y: 18, opacity: 0 },
          { y: 0, opacity: 1, ease: 'none' },
          0.18 + i * 0.04
        );
      });

      // SETTLE (30% - 70%): Parallax
      const images = sectionRef.current?.querySelectorAll('.parallax-image');
      images?.forEach((img) => {
        scrollTl.fromTo(img,
          { y: 0 },
          { y: '-1.5vh', ease: 'none' },
          0.30
        );
      });

      // EXIT (70% - 100%)
      scrollTl.fromTo(leftCardRef.current,
        { x: 0, opacity: 1 },
        { x: '-55vw', opacity: 0, ease: 'power2.in' },
        0.70
      );

      scrollTl.fromTo([topRightCardRef.current, bottomRightCardRef.current],
        { x: 0, opacity: 1 },
        { x: '55vw', opacity: 0, ease: 'power2.in', stagger: 0.02 },
        0.70
      );

    }, sectionRef);

    return () => ctx.revert();
  }, []);

  return (
    <section
      ref={sectionRef}
      className="section-pinned bg-[#F4F6F8] z-[90]"
      style={{ perspective: '1000px' }}
    >
      <div className="w-full h-full relative px-[6vw] py-[10vh]">
        {/* Left Large Card */}
        <div
          ref={leftCardRef}
          className="absolute left-[6vw] top-[10vh] w-[44vw] h-[80vh] image-card group cursor-pointer preserve-3d"
        >
          <div className="relative w-full h-full overflow-hidden">
            <img
              src={notes[0].image}
              alt={notes[0].title}
              className="parallax-image w-full h-full object-cover scale-110 transition-transform duration-700 group-hover:scale-100"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent" />
            <div className="note-label absolute bottom-6 left-6 text-white">
              <p className="label-mono text-white/70 mb-2">{notes[0].category}</p>
              <p className="font-['Sora'] text-xl font-bold">{notes[0].title}</p>
            </div>
          </div>
        </div>

        {/* Top Right Card */}
        <div
          ref={topRightCardRef}
          className="absolute left-[52vw] top-[10vh] w-[42vw] h-[38vh] image-card group cursor-pointer"
        >
          <div className="relative w-full h-full overflow-hidden">
            <img
              src={notes[1].image}
              alt={notes[1].title}
              className="parallax-image w-full h-full object-cover scale-110 transition-transform duration-700 group-hover:scale-100"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent" />
            <div className="note-label absolute bottom-6 left-6 text-white">
              <p className="label-mono text-white/70 mb-2">{notes[1].category}</p>
              <p className="font-['Sora'] text-xl font-bold">{notes[1].title}</p>
            </div>
          </div>
        </div>

        {/* Bottom Right Card */}
        <div
          ref={bottomRightCardRef}
          className="absolute left-[52vw] top-[52vh] w-[42vw] h-[38vh] image-card group cursor-pointer"
        >
          <div className="relative w-full h-full overflow-hidden">
            <img
              src={notes[2].image}
              alt={notes[2].title}
              className="parallax-image w-full h-full object-cover scale-110 transition-transform duration-700 group-hover:scale-100"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent" />
            <div className="note-label absolute bottom-6 left-6 text-white">
              <p className="label-mono text-white/70 mb-2">{notes[2].category}</p>
              <p className="font-['Sora'] text-xl font-bold">{notes[2].title}</p>
            </div>
          </div>
        </div>

        {/* All Notes Link */}
        <a
          href="#notes"
          className="absolute left-1/2 -translate-x-1/2 bottom-[4vh] text-[#2F6BFF] text-sm font-medium hover:underline flex items-center gap-2"
        >
          All notes
          <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 8l4 4m0 0l-4 4m4-4H3" />
          </svg>
        </a>
      </div>
    </section>
  );
};

export default StudioNotes;
