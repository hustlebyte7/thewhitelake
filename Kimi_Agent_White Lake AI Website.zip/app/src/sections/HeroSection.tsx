import { useEffect, useRef, useLayoutEffect } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

const HeroSection = () => {
  const sectionRef = useRef<HTMLElement>(null);
  const photoCardRef = useRef<HTMLDivElement>(null);
  const headlineRef = useRef<HTMLDivElement>(null);
  const ctaRowRef = useRef<HTMLDivElement>(null);
  const captionRef = useRef<HTMLDivElement>(null);

  // Entrance animation on load
  useEffect(() => {
    const ctx = gsap.context(() => {
      const tl = gsap.timeline({ defaults: { ease: 'power3.out' } });

      // Photo card entrance
      tl.fromTo(photoCardRef.current,
        { opacity: 0, x: '-12vw', scale: 0.98, rotateY: 6 },
        { opacity: 1, x: 0, scale: 1, rotateY: 0, duration: 1 },
        0
      );

      // Headline entrance (split by words)
      const words = headlineRef.current?.querySelectorAll('.word');
      if (words) {
        tl.fromTo(words,
          { opacity: 0, y: 40 },
          { opacity: 1, y: 0, duration: 0.8, stagger: 0.06 },
          0.2
        );
      }

      // Subheadline
      const subheadline = headlineRef.current?.querySelector('.subheadline');
      if (subheadline) {
        tl.fromTo(subheadline,
          { opacity: 0, y: 20 },
          { opacity: 1, y: 0, duration: 0.6 },
          0.5
        );
      }

      // CTA row
      tl.fromTo(ctaRowRef.current,
        { opacity: 0, y: 18 },
        { opacity: 1, y: 0, duration: 0.6 },
        0.7
      );

      // Caption
      tl.fromTo(captionRef.current,
        { opacity: 0 },
        { opacity: 1, duration: 0.6 },
        0.9
      );
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  // Scroll-driven exit animation
  useLayoutEffect(() => {
    const ctx = gsap.context(() => {
      const scrollTl = gsap.timeline({
        scrollTrigger: {
          trigger: sectionRef.current,
          start: 'top top',
          end: '+=130%',
          pin: true,
          scrub: 0.6,
          onLeaveBack: () => {
            // Reset all elements when scrolling back to top
            gsap.set([photoCardRef.current, headlineRef.current, ctaRowRef.current, captionRef.current], {
              opacity: 1, x: 0, y: 0, rotateZ: 0
            });
          }
        }
      });

      // SETTLE phase (0% - 70%): Hold position with micro parallax
      // Photo inner parallax
      const photoInner = photoCardRef.current?.querySelector('.parallax-image');
      if (photoInner) {
        scrollTl.fromTo(photoInner,
          { y: 0 },
          { y: '-1.5vh', ease: 'none' },
          0
        );
      }

      // EXIT phase (70% - 100%)
      scrollTl.fromTo(photoCardRef.current,
        { x: 0, rotateZ: 0, opacity: 1 },
        { x: '-55vw', rotateZ: -2, opacity: 0, ease: 'power2.in' },
        0.70
      );

      scrollTl.fromTo(headlineRef.current,
        { x: 0, opacity: 1 },
        { x: '22vw', opacity: 0, ease: 'power2.in' },
        0.70
      );

      scrollTl.fromTo(ctaRowRef.current,
        { y: 0, opacity: 1 },
        { y: '10vh', opacity: 0, ease: 'power2.in' },
        0.72
      );

      scrollTl.fromTo(captionRef.current,
        { opacity: 1 },
        { opacity: 0, ease: 'power2.in' },
        0.75
      );

    }, sectionRef);

    return () => ctx.revert();
  }, []);

  return (
    <section
      ref={sectionRef}
      className="section-pinned bg-[#F4F6F8] z-10 flex items-center justify-center"
      style={{ perspective: '1000px' }}
    >
      {/* Subtle vignette */}
      <div className="absolute inset-0 pointer-events-none"
        style={{
          background: 'radial-gradient(ellipse at center, transparent 0%, rgba(0,0,0,0.03) 100%)'
        }}
      />

      {/* Blue glow behind text */}
      <div className="absolute right-[10vw] top-[20vh] w-[40vw] h-[50vh] pointer-events-none opacity-30"
        style={{
          background: 'radial-gradient(ellipse at center, rgba(47,107,255,0.15) 0%, transparent 70%)'
        }}
      />

      <div className="w-full h-full relative px-[6vw] py-[14vh]">
        {/* Left Photo Card */}
        <div
          ref={photoCardRef}
          className="absolute left-[6vw] top-[14vh] w-[42vw] h-[72vh] image-card preserve-3d"
          style={{ transformStyle: 'preserve-3d' }}
        >
          <div className="w-full h-full overflow-hidden">
            <img
              src="/hero_portrait.jpg"
              alt="Editorial portrait"
              className="parallax-image w-full h-full object-cover scale-110"
            />
          </div>
        </div>

        {/* Right Headline Block */}
        <div
          ref={headlineRef}
          className="absolute left-[54vw] top-[26vh] w-[40vw]"
        >
          <h1 className="text-[64px] lg:text-[80px] xl:text-[96px] leading-[0.95] text-[#0B0D10] mb-6">
            <span className="word inline-block">Quiet</span>{' '}
            <span className="word inline-block">work.</span>
            <br />
            <span className="word inline-block">Loud</span>{' '}
            <span className="word inline-block">craft.</span>
          </h1>
          <p className="subheadline text-lg text-[#6B7280] max-w-md">
            A creative studio building brand worlds with restraint.
          </p>
        </div>

        {/* CTA Row */}
        <div
          ref={ctaRowRef}
          className="absolute left-[54vw] top-[62vh] flex items-center gap-4"
        >
          <button className="btn-pill btn-primary">
            Explore work
          </button>
          <button className="btn-pill btn-secondary">
            Meet the studio
          </button>
        </div>

        {/* Bottom Right Caption */}
        <div
          ref={captionRef}
          className="absolute right-[6vw] bottom-[8vh] text-right"
        >
          <p className="label-mono">Scroll to enter the gallery.</p>
        </div>
      </div>
    </section>
  );
};

export default HeroSection;
