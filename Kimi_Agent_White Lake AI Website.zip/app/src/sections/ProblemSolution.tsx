import { useEffect, useRef } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Clock, Database, TrendingUp, Users, CheckCircle2, ArrowRight } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

const problems = [
  {
    icon: Clock,
    text: 'Manual processes eating up team hours'
  },
  {
    icon: Database,
    text: 'Data scattered across systems with no automation'
  },
  {
    icon: TrendingUp,
    text: 'Operational costs climbing without ROI'
  },
  {
    icon: Users,
    text: 'No in-house AI expertise to execute'
  }
];

const solutions = [
  {
    icon: CheckCircle2,
    text: 'Intelligent workflows that run 24/7'
  },
  {
    icon: CheckCircle2,
    text: 'Unified data pipelines with real-time sync'
  },
  {
    icon: CheckCircle2,
    text: 'Systems that reduce costs by 40-60%'
  },
  {
    icon: CheckCircle2,
    text: 'End-to-end implementation + ongoing support'
  }
];

const ProblemSolution = () => {
  const sectionRef = useRef<HTMLElement>(null);
  const headingRef = useRef<HTMLDivElement>(null);
  const problemsRef = useRef<HTMLDivElement>(null);
  const solutionsRef = useRef<HTMLDivElement>(null);
  const arrowRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      // Heading
      gsap.fromTo(headingRef.current,
        { opacity: 0, y: 30 },
        {
          opacity: 1,
          y: 0,
          duration: 0.6,
          scrollTrigger: {
            trigger: headingRef.current,
            start: 'top 80%',
            toggleActions: 'play none none reverse'
          }
        }
      );

      // Problem cards
      const problemCards = problemsRef.current?.querySelectorAll('.problem-card');
      problemCards?.forEach((card, i) => {
        gsap.fromTo(card,
          { opacity: 0, x: -30 },
          {
            opacity: 1,
            x: 0,
            duration: 0.5,
            delay: i * 0.1,
            scrollTrigger: {
              trigger: problemsRef.current,
              start: 'top 75%',
              toggleActions: 'play none none reverse'
            }
          }
        );
      });

      // Arrow
      gsap.fromTo(arrowRef.current,
        { opacity: 0, scale: 0.8 },
        {
          opacity: 1,
          scale: 1,
          duration: 0.5,
          scrollTrigger: {
            trigger: arrowRef.current,
            start: 'top 75%',
            toggleActions: 'play none none reverse'
          }
        }
      );

      // Solution cards
      const solutionCards = solutionsRef.current?.querySelectorAll('.solution-card');
      solutionCards?.forEach((card, i) => {
        gsap.fromTo(card,
          { opacity: 0, x: 30 },
          {
            opacity: 1,
            x: 0,
            duration: 0.5,
            delay: i * 0.1,
            scrollTrigger: {
              trigger: solutionsRef.current,
              start: 'top 75%',
              toggleActions: 'play none none reverse'
            }
          }
        );
      });
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  return (
    <section
      ref={sectionRef}
      className="py-20 lg:py-32 bg-white"
    >
      <div className="section-padding">
        <div ref={headingRef} className="text-center max-w-3xl mx-auto mb-16">
          <span className="label-mono text-blue-600 mb-4 block">The Challenge</span>
          <h2 className="text-3xl lg:text-5xl font-bold text-slate-900 mb-4">
            From Manual Chaos to Automated Efficiency
          </h2>
          <p className="text-lg text-slate-600">
            We solve the problems that keep business leaders awake at night.
          </p>
        </div>

        <div className="grid lg:grid-cols-3 gap-8 lg:gap-12 items-center max-w-6xl mx-auto">
          {/* Problems */}
          <div ref={problemsRef} className="space-y-4">
            <h3 className="text-lg font-semibold text-slate-900 mb-6 flex items-center gap-2">
              <span className="w-8 h-8 rounded-full bg-red-100 flex items-center justify-center">
                <span className="text-red-600 text-sm font-bold">!</span>
              </span>
              The Problem
            </h3>
            {problems.map((problem, i) => (
              <div
                key={i}
                className="problem-card flex items-start gap-4 p-4 rounded-xl bg-slate-50 border border-slate-100 card-hover"
              >
                <div className="w-10 h-10 rounded-lg bg-red-100 flex items-center justify-center flex-shrink-0">
                  <problem.icon className="w-5 h-5 text-red-600" />
                </div>
                <p className="text-slate-700 font-medium">{problem.text}</p>
              </div>
            ))}
          </div>

          {/* Arrow */}
          <div ref={arrowRef} className="hidden lg:flex justify-center">
            <div className="w-16 h-16 rounded-full bg-blue-600 flex items-center justify-center shadow-lg shadow-blue-600/25">
              <ArrowRight className="w-8 h-8 text-white" />
            </div>
          </div>

          {/* Solutions */}
          <div ref={solutionsRef} className="space-y-4">
            <h3 className="text-lg font-semibold text-slate-900 mb-6 flex items-center gap-2">
              <span className="w-8 h-8 rounded-full bg-emerald-100 flex items-center justify-center">
                <CheckCircle2 className="w-5 h-5 text-emerald-600" />
              </span>
              Our Solution
            </h3>
            {solutions.map((solution, i) => (
              <div
                key={i}
                className="solution-card flex items-start gap-4 p-4 rounded-xl bg-blue-50 border border-blue-100 card-hover"
              >
                <div className="w-10 h-10 rounded-lg bg-blue-600 flex items-center justify-center flex-shrink-0">
                  <solution.icon className="w-5 h-5 text-white" />
                </div>
                <p className="text-slate-700 font-medium">{solution.text}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default ProblemSolution;
