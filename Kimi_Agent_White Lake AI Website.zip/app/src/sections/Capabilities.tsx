import { useRef, useLayoutEffect } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Lightbulb, Palette, Camera, Globe, ImageIcon, Video } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

const capabilities = [
  { icon: Lightbulb, title: 'Brand Strategy', description: 'Positioning, messaging, and market differentiation' },
  { icon: Palette, title: 'Visual Identity',n: 'Logos, color systems, and brand guidelines' },
  { icon: Camera, title: 'Art Direction', description: 'Creative vision and visual storytelling' },
  { icon: Globe, title: 'Web Experiences', description: 'Digital platforms that convert and inspire' },
  { icon: ImageIcon, title: 'Photography Direction', description: 'Visual narratives that capture essence' },
  { icon: Video, title: 'Motion Systems', description: 'Animation and video that brings brands to life' },
];

const Capabilities = () => {
  const sectionRef = useRef<HTMLElement>(null);
  const headingRef = useRef<HTMLDivElement>(null);
  const cardsRef = useRef<(HTMLDivElement | null)[]>([]);
  const blobRef = useRef<HTMLDivElement>(null);

  useLayoutEffect(() => {
    const ctx = gsap.context(() => {
      // Heading animation
      gsap.fromTo(headingRef.current,
        { y: 40, opacity: 0 },
        {
          y: 0,
          opacity: 1,
          duration: 0.8,
          ease: 'power3.out',
          scrollTrigger: {
            trigger: headingRef.current,
            start: 'top 80%',
            toggleActions: 'play none none reverse'
          }
        }
      );

      // Cards animation
      cardsRef.current.forEach((card, i) => {
        if (card) {
          gsap.fromTo(card,
            { x: '10vw', opacity: 0, rotateZ: 1 },
            {
              x: 0,
              opacity: 1,
              rotateZ: 0,
              duration: 0.6,
              delay: i * 0.1,
              ease: 'power3.out',
              scrollTrigger: {
                trigger: card,
                start: 'top 85%',
                toggleActions: 'play none none reverse'
              }
            }
          );
        }
      });

      // Blob rotation
      gsap.to(blobRef.current, {
        rotation: 12,
        ease: 'none',
        scrollTrigger: {
          trigger: sectionRef.current,
          start: 'top bottom',
          end: 'bottom top',
          scrub: true
        }
      });

    }, sectionRef);

    return () => ctx.revert();
  }, []);

  return (
    <section
      ref={sectionRef}
      className="relative bg-[#F4F6F8] z-50 py-24 lg:py-32"
    >
      {/* Blue glow blob */}
      <div
        ref={blobRef}
        className="absolute right-0 top-1/2 -translate-y-1/2 w-[50vw] h-[50vw] pointer-events-none opacity-20"
        style={{
          background: 'radial-gradient(ellipse at center, rgba(47,107,255,0.3) 0%, transparent 60%)'
        }}
      />

      <div className="w-full px-[6vw] relative">
        <div className="grid lg:grid-cols-2 gap-16 lg:gap-24">
          {/* Left Column - Heading */}
          <div ref={headingRef} className="lg:sticky lg:top-32 lg:self-start">
            <h2 className="text-5xl lg:text-6xl text-[#0B0D10] mb-6">
              Capabilities
            </h2>
            <p className="text-lg text-[#6B7280] max-w-md leading-relaxed">
              Strategy, identity, digital, and campaign systems—built as one coherent world.
            </p>
          </div>

          {/* Right Column - Cards */}
          <div className="space-y-4">
            {capabilities.map((cap, i) => (
              <div
                key={cap.title}
                ref={el => { cardsRef.current[i] = el; }}
                className="group bg-white rounded-2xl p-6 shadow-sm hover:shadow-lg transition-all duration-300 cursor-pointer hover:-translate-y-1"
              >
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 rounded-xl bg-[#2F6BFF]/10 flex items-center justify-center flex-shrink-0 group-hover:bg-[#2F6BFF] transition-colors duration-300">
                    <cap.icon className="w-5 h-5 text-[#2F6BFF] group-hover:text-white transition-colors duration-300" />
                  </div>
                  <div>
                    <h3 className="font-['Sora'] text-lg font-semibold text-[#0B0D10] mb-1">
                      {cap.title}
                    </h3>
                    <p className="text-sm text-[#6B7280]">
                      {cap.description}
                    </p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default Capabilities;
