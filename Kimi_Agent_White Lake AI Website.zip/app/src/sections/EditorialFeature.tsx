import { useRef, useLayoutEffect } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

const EditorialFeature = () => {
  const sectionRef = useRef<HTMLElement>(null);
  const imageCardRef = useRef<HTMLDivElement>(null);
  const headlineRef = useRef<HTMLHeadingElement>(null);
  const bodyRef = useRef<HTMLParagraphElement>(null);
  const ctaRef = useRef<HTMLAnchorElement>(null);
  const captionRef = useRef<HTMLParagraphElement>(null);

  useLayoutEffect(() => {
    const ctx = gsap.context(() => {
      const scrollTl = gsap.timeline({
        scrollTrigger: {
          trigger: sectionRef.current,
          start: 'top top',
          end: '+=130%',
          pin: true,
          scrub: 0.6,
        }
      });

      // ENTRANCE (0% - 30%)
      scrollTl.fromTo(imageCardRef.current,
        { x: '70vw', opacity: 0, rotateY: -6 },
        { x: 0, opacity: 1, rotateY: 0, ease: 'none' },
        0
      );

      scrollTl.fromTo(headlineRef.current,
        { x: '-30vw', opacity: 0 },
        { x: 0, opacity: 1, ease: 'none' },
        0.08
      );

      scrollTl.fromTo(bodyRef.current,
        { y: 18, opacity: 0 },
        { y: 0, opacity: 1, ease: 'none' },
        0.14
      );

      scrollTl.fromTo(ctaRef.current,
        { y: 18, opacity: 0 },
        { y: 0, opacity: 1, ease: 'none' },
        0.18
      );

      scrollTl.fromTo(captionRef.current,
        { opacity: 0 },
        { opacity: 1, ease: 'none' },
        0.22
      );

      // SETTLE (30% - 70%): Parallax
      const image = imageCardRef.current?.querySelector('.parallax-image');
      if (image) {
        scrollTl.fromTo(image,
          { y: 0 },
          { y: '-1.5vh', ease: 'none' },
          0.30
        );
      }

      // EXIT (70% - 100%)
      scrollTl.fromTo(imageCardRef.current,
        { x: 0, opacity: 1 },
        { x: '55vw', opacity: 0, ease: 'power2.in' },
        0.70
      );

      scrollTl.fromTo([headlineRef.current, bodyRef.current, ctaRef.current, captionRef.current],
        { x: 0, opacity: 1 },
        { x: '-25vw', opacity: 0, ease: 'power2.in', stagger: 0.02 },
        0.70
      );

    }, sectionRef);

    return () => ctx.revert();
  }, []);

  return (
    <section
      ref={sectionRef}
      className="section-pinned bg-[#F4F6F8] z-[70]"
      style={{ perspective: '1000px' }}
    >
      <div className="w-full h-full relative px-[6vw] py-[10vh]">
        {/* Left Content */}
        <div className="absolute left-[6vw] top-[18vh] w-[34vw]">
          <h2
            ref={headlineRef}
            className="text-5xl lg:text-6xl text-[#0B0D10] mb-8"
          >
            Editorial
          </h2>
          <p
            ref={bodyRef}
            className="text-[#6B7280] leading-relaxed mb-8"
          >
            We treat every campaign like a magazine story: sequence, contrast, and intent.
          </p>
          <a
            ref={ctaRef}
            href="#archive"
            className="inline-flex items-center gap-2 text-[#2F6BFF] font-medium hover:underline"
          >
            Explore the archive
            <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 8l4 4m0 0l-4 4m4-4H3" />
            </svg>
          </a>
        </div>

        {/* Large Right Image Card */}
        <div
          ref={imageCardRef}
          className="absolute left-[42vw] top-[10vh] w-[52vw] h-[80vh] image-card preserve-3d"
        >
          <div className="relative w-full h-full overflow-hidden">
            <img
              src="/editorial_lisbon_street.jpg"
              alt="Editorial feature"
              className="parallax-image w-full h-full object-cover scale-110"
            />
            {/* Caption inside card */}
            <div className="absolute bottom-6 left-6">
              <p
                ref={captionRef}
                className="label-mono text-white/70"
              >
                Location: Lisbon — Studio Archive
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default EditorialFeature;
