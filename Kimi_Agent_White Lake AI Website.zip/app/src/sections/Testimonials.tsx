import { useEffect, useRef } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Quote } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

const testimonials = [
  {
    quote: "The White Lake didn't just consult — they built and deployed our entire AI infrastructure in 8 weeks. Our operational costs dropped 45%.",
    name: 'Sarah Chen',
    title: 'COO',
    company: 'TechFlow'
  },
  {
    quote: "Finally, an AI team that speaks business. They understood our pain points and delivered systems that actually work.",
    name: 'Marcus Johnson',
    title: 'CTO',
    company: 'DataPrime'
  },
  {
    quote: "We went from manual everything to 80% automated in 3 months. The ROI was clear within the first quarter.",
    name: 'Elena Rodriguez',
    title: 'VP Operations',
    company: 'ScaleInc'
  }
];

const Testimonials = () => {
  const sectionRef = useRef<HTMLElement>(null);
  const headingRef = useRef<HTMLDivElement>(null);
  const cardsRef = useRef<(HTMLDivElement | null)[]>([]);

  useEffect(() => {
    const ctx = gsap.context(() => {
      gsap.fromTo(headingRef.current,
        { opacity: 0, y: 30 },
        {
          opacity: 1,
          y: 0,
          duration: 0.6,
          scrollTrigger: {
            trigger: headingRef.current,
            start: 'top 80%',
            toggleActions: 'play none none reverse'
          }
        }
      );

      cardsRef.current.forEach((card, i) => {
        if (card) {
          gsap.fromTo(card,
            { opacity: 0, y: 40 },
            {
              opacity: 1,
              y: 0,
              duration: 0.6,
              delay: i * 0.15,
              scrollTrigger: {
                trigger: card,
                start: 'top 85%',
                toggleActions: 'play none none reverse'
              }
            }
          );
        }
      });
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  return (
    <section
      ref={sectionRef}
      className="py-20 lg:py-32 bg-[#FAFBFC]"
    >
      <div className="section-padding">
        <div ref={headingRef} className="text-center max-w-3xl mx-auto mb-16">
          <span className="label-mono text-blue-600 mb-4 block">Testimonials</span>
          <h2 className="text-3xl lg:text-5xl font-bold text-slate-900 mb-4">
            What Our Clients Say
          </h2>
          <p className="text-lg text-slate-600">
            Don't just take our word for it.
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8 max-w-6xl mx-auto">
          {testimonials.map((testimonial, i) => (
            <div
              key={testimonial.name}
              ref={el => { cardsRef.current[i] = el; }}
              className="bg-white rounded-2xl p-8 border border-slate-100 shadow-sm relative"
            >
              {/* Quote Icon */}
              <div className="absolute -top-4 left-8 w-8 h-8 bg-blue-600 rounded-full flex items-center justify-center">
                <Quote className="w-4 h-4 text-white" />
              </div>

              <p className="text-slate-700 leading-relaxed mb-6 pt-4">
                "{testimonial.quote}"
              </p>

              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-full bg-slate-200 flex items-center justify-center">
                  <span className="text-slate-600 font-bold">
                    {testimonial.name.split(' ').map(n => n[0]).join('')}
                  </span>
                </div>
                <div>
                  <p className="font-semibold text-slate-900">{testimonial.name}</p>
                  <p className="text-sm text-slate-500">
                    {testimonial.title}, {testimonial.company}
                  </p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Testimonials;
