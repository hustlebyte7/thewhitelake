import { useEffect, useRef } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { ArrowRight, TrendingDown, Clock, CheckCircle } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

const caseStudies = [
  {
    image: '/case_manufacturing.jpg',
    industry: 'Manufacturing',
    challenge: 'Manual order processing taking 3 days',
    solution: 'AI-powered order intake + ERP integration',
    results: [
      { icon: TrendingDown, value: '90%', label: 'Faster processing' },
      { icon: CheckCircle, value: '$400K', label: 'Annual savings' }
    ]
  },
  {
    image: '/case_saas.jpg',
    industry: 'SaaS',
    challenge: 'Support team overwhelmed with tickets',
    solution: 'AI agent for L1 support + escalation logic',
    results: [
      { icon: CheckCircle, value: '70%', label: 'Auto-resolved' },
      { icon: Clock, value: '2min', label: 'Avg response' }
    ]
  },
  {
    image: '/case_finance.jpg',
    industry: 'Financial Services',
    challenge: 'Compliance reporting taking 40 hours/month',
    solution: 'Automated data pipeline + report generation',
    results: [
      { icon: TrendingDown, value: '95%', label: 'Time reduction' },
      { icon: CheckCircle, value: '0', label: 'Errors' }
    ]
  }
];

const CaseStudies = () => {
  const sectionRef = useRef<HTMLElement>(null);
  const headingRef = useRef<HTMLDivElement>(null);
  const cardsRef = useRef<(HTMLDivElement | null)[]>([]);

  useEffect(() => {
    const ctx = gsap.context(() => {
      gsap.fromTo(headingRef.current,
        { opacity: 0, y: 30 },
        {
          opacity: 1,
          y: 0,
          duration: 0.6,
          scrollTrigger: {
            trigger: headingRef.current,
            start: 'top 80%',
            toggleActions: 'play none none reverse'
          }
        }
      );

      cardsRef.current.forEach((card, i) => {
        if (card) {
          gsap.fromTo(card,
            { opacity: 0, y: 50 },
            {
              opacity: 1,
              y: 0,
              duration: 0.6,
              delay: i * 0.15,
              scrollTrigger: {
                trigger: card,
                start: 'top 85%',
                toggleActions: 'play none none reverse'
              }
            }
          );
        }
      });
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  return (
    <section
      ref={sectionRef}
      className="py-20 lg:py-32 bg-[#FAFBFC]"
    >
      <div className="section-padding">
        <div ref={headingRef} className="text-center max-w-3xl mx-auto mb-16">
          <span className="label-mono text-blue-600 mb-4 block">Case Studies</span>
          <h2 className="text-3xl lg:text-5xl font-bold text-slate-900 mb-4">
            Real Results for Real Businesses
          </h2>
          <p className="text-lg text-slate-600">
            See how we've helped companies transform their operations.
          </p>
        </div>

        <div className="grid lg:grid-cols-3 gap-8 max-w-7xl mx-auto">
          {caseStudies.map((study, i) => (
            <div
              key={study.industry}
              ref={el => { cardsRef.current[i] = el; }}
              className="group bg-white rounded-2xl overflow-hidden border border-slate-100 shadow-sm card-hover cursor-pointer"
            >
              {/* Image */}
              <div className="relative h-48 overflow-hidden">
                <img
                  src={study.image}
                  alt={study.industry}
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                />
                <div className="absolute top-4 left-4">
                  <span className="px-3 py-1 bg-white/90 backdrop-blur-sm rounded-full text-sm font-medium text-slate-700">
                    {study.industry}
                  </span>
                </div>
              </div>

              {/* Content */}
              <div className="p-6">
                <div className="mb-4">
                  <p className="label-mono text-red-500 mb-1">Challenge</p>
                  <p className="text-slate-700 font-medium">{study.challenge}</p>
                </div>

                <div className="mb-6">
                  <p className="label-mono text-blue-600 mb-1">Solution</p>
                  <p className="text-slate-700">{study.solution}</p>
                </div>

                {/* Results */}
                <div className="flex gap-4 pt-4 border-t border-slate-100">
                  {study.results.map((result, j) => (
                    <div key={j} className="flex items-center gap-2">
                      <result.icon className="w-4 h-4 text-emerald-500" />
                      <span className="font-bold text-slate-900">{result.value}</span>
                      <span className="text-xs text-slate-500">{result.label}</span>
                    </div>
                  ))}
                </div>

                <div className="mt-6 flex items-center text-blue-600 font-medium text-sm group-hover:gap-3 gap-2 transition-all">
                  Read full case study
                  <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default CaseStudies;
