import { useRef, useLayoutEffect } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

const CollaborationCTA = () => {
  const sectionRef = useRef<HTMLElement>(null);
  const imageCardRef = useRef<HTMLDivElement>(null);
  const headlineRef = useRef<HTMLHeadingElement>(null);
  const bodyRef = useRef<HTMLParagraphElement>(null);
  const ctaRowRef = useRef<HTMLDivElement>(null);
  const pillRef = useRef<HTMLSpanElement>(null);

  useLayoutEffect(() => {
    const ctx = gsap.context(() => {
      const scrollTl = gsap.timeline({
        scrollTrigger: {
          trigger: sectionRef.current,
          start: 'top top',
          end: '+=130%',
          pin: true,
          scrub: 0.6,
        }
      });

      // ENTRANCE (0% - 30%)
      scrollTl.fromTo(imageCardRef.current,
        { x: '70vw', opacity: 0, rotateY: -6 },
        { x: 0, opacity: 1, rotateY: 0, ease: 'none' },
        0
      );

      scrollTl.fromTo(headlineRef.current,
        { x: '-30vw', opacity: 0 },
        { x: 0, opacity: 1, ease: 'none' },
        0.08
      );

      scrollTl.fromTo(bodyRef.current,
        { y: 18, opacity: 0 },
        { y: 0, opacity: 1, ease: 'none' },
        0.14
      );

      scrollTl.fromTo(ctaRowRef.current,
        { y: 18, opacity: 0 },
        { y: 0, opacity: 1, ease: 'none' },
        0.18
      );

      scrollTl.fromTo(pillRef.current,
        { scale: 0.85, opacity: 0 },
        { scale: 1, opacity: 1, ease: 'none' },
        0.20
      );

      // SETTLE (30% - 70%): Parallax
      const image = imageCardRef.current?.querySelector('.parallax-image');
      if (image) {
        scrollTl.fromTo(image,
          { y: 0 },
          { y: '-1.5vh', ease: 'none' },
          0.30
        );
      }

      // EXIT (70% - 100%)
      scrollTl.fromTo(imageCardRef.current,
        { x: 0, opacity: 1 },
        { x: '55vw', opacity: 0, ease: 'power2.in' },
        0.70
      );

      scrollTl.fromTo([headlineRef.current, bodyRef.current, ctaRowRef.current, pillRef.current],
        { x: 0, opacity: 1 },
        { x: '-25vw', opacity: 0, ease: 'power2.in', stagger: 0.02 },
        0.70
      );

    }, sectionRef);

    return () => ctx.revert();
  }, []);

  return (
    <section
      ref={sectionRef}
      className="section-pinned bg-[#F4F6F8] z-[100]"
      style={{ perspective: '1000px' }}
    >
      <div className="w-full h-full relative px-[6vw] py-[10vh]">
        {/* Left Content */}
        <div className="absolute left-[6vw] top-[18vh] w-[34vw]">
          <h2
            ref={headlineRef}
            className="text-5xl lg:text-6xl text-[#0B0D10] mb-8"
          >
            Collaborate
          </h2>
          <p
            ref={bodyRef}
            className="text-[#6B7280] leading-relaxed mb-8"
          >
            Tell us what you're building. We'll respond within two business days.
          </p>
          <div ref={ctaRowRef} className="flex items-center gap-4 mb-6">
            <button className="btn-pill btn-primary">
              Start a project
            </button>
            <a
              href="#capabilities"
              className="text-[#0B0D10]/70 text-sm hover:text-[#0B0D10] transition-colors flex items-center gap-2"
            >
              Download capabilities (PDF)
              <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
              </svg>
            </a>
          </div>
          <span
            ref={pillRef}
            className="inline-block px-3 py-1.5 bg-[#2F6BFF]/10 text-[#2F6BFF] text-xs font-mono uppercase tracking-wider rounded-full"
          >
            Booking next month
          </span>
        </div>

        {/* Large Right Image Card */}
        <div
          ref={imageCardRef}
          className="absolute left-[42vw] top-[10vh] w-[52vw] h-[80vh] image-card preserve-3d"
        >
          <img
            src="/collaborate_portrait.jpg"
            alt="Collaboration"
            className="parallax-image w-full h-full object-cover scale-110"
          />
        </div>
      </div>
    </section>
  );
};

export default CollaborationCTA;
