import { useRef, useLayoutEffect } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

const StudioSnapshot = () => {
  const sectionRef = useRef<HTMLElement>(null);
  const titleCardRef = useRef<HTMLDivElement>(null);
  const portraitCardRef = useRef<HTMLDivElement>(null);
  const buildingCardRef = useRef<HTMLDivElement>(null);
  const studioCardRef = useRef<HTMLDivElement>(null);
  const textCardRef = useRef<HTMLDivElement>(null);
  const pillRef = useRef<HTMLSpanElement>(null);

  useLayoutEffect(() => {
    const ctx = gsap.context(() => {
      const scrollTl = gsap.timeline({
        scrollTrigger: {
          trigger: sectionRef.current,
          start: 'top top',
          end: '+=130%',
          pin: true,
          scrub: 0.6,
        }
      });

      // ENTRANCE (0% - 30%)
      // Title card from left
      scrollTl.fromTo(titleCardRef.current,
        { x: '-50vw', opacity: 0 },
        { x: 0, opacity: 1, ease: 'none' },
        0
      );

      // Portrait from top
      scrollTl.fromTo(portraitCardRef.current,
        { y: '-35vh', opacity: 0, scale: 0.96 },
        { y: 0, opacity: 1, scale: 1, ease: 'none' },
        0.06
      );

      // Building from right
      scrollTl.fromTo(buildingCardRef.current,
        { x: '50vw', opacity: 0 },
        { x: 0, opacity: 1, ease: 'none' },
        0.08
      );

      // Studio card from left
      scrollTl.fromTo(studioCardRef.current,
        { x: '-60vw', opacity: 0, rotateZ: -1 },
        { x: 0, opacity: 1, rotateZ: 0, ease: 'none' },
        0.10
      );

      // Text card from right
      scrollTl.fromTo(textCardRef.current,
        { x: '55vw', opacity: 0 },
        { x: 0, opacity: 1, ease: 'none' },
        0.12
      );

      // Pill scale
      scrollTl.fromTo(pillRef.current,
        { scale: 0.8, opacity: 0 },
        { scale: 1, opacity: 1, ease: 'none' },
        0.18
      );

      // SETTLE (30% - 70%): Micro parallax on images
      const images = sectionRef.current?.querySelectorAll('.parallax-image');
      images?.forEach((img) => {
        scrollTl.fromTo(img,
          { y: 0 },
          { y: '-1vh', ease: 'none' },
          0.30
        );
      });

      // EXIT (70% - 100%)
      scrollTl.fromTo(studioCardRef.current,
        { x: 0, opacity: 1 },
        { x: '-55vw', opacity: 0, ease: 'power2.in' },
        0.70
      );

      scrollTl.fromTo(textCardRef.current,
        { x: 0, opacity: 1 },
        { x: '55vw', opacity: 0, ease: 'power2.in' },
        0.70
      );

      scrollTl.fromTo([titleCardRef.current, portraitCardRef.current, buildingCardRef.current],
        { y: 0, opacity: 1 },
        { y: '-18vh', opacity: 0, ease: 'power2.in', stagger: 0.02 },
        0.72
      );

    }, sectionRef);

    return () => ctx.revert();
  }, []);

  return (
    <section
      ref={sectionRef}
      className="section-pinned bg-[#F4F6F8] z-20"
    >
      <div className="w-full h-full relative px-[6vw] py-[10vh]">
        {/* Top Row */}
        {/* Title Card */}
        <div
          ref={titleCardRef}
          className="absolute left-[6vw] top-[10vh] w-[34vw] h-[22vh] text-card flex flex-col justify-center px-8"
        >
          <h2 className="text-4xl lg:text-5xl text-[#0B0D10] mb-2">Studio</h2>
          <p className="text-[#6B7280] text-sm">A small team obsessed with clarity.</p>
        </div>

        {/* Portrait Card */}
        <div
          ref={portraitCardRef}
          className="absolute left-[42vw] top-[10vh] w-[26vw] h-[22vh] image-card"
        >
          <img
            src="/studio_portrait_closeup.jpg"
            alt="Studio portrait"
            className="parallax-image w-full h-full object-cover scale-110"
          />
        </div>

        {/* Building Card */}
        <div
          ref={buildingCardRef}
          className="absolute left-[70vw] top-[10vh] w-[24vw] h-[22vh] image-card"
        >
          <img
            src="/studio_building_exterior.jpg"
            alt="Studio building"
            className="parallax-image w-full h-full object-cover scale-110"
          />
        </div>

        {/* Bottom Row */}
        {/* Large Studio Card */}
        <div
          ref={studioCardRef}
          className="absolute left-[6vw] top-[36vh] w-[62vw] h-[54vh] image-card"
        >
          <img
            src="/studio_interior_wide.jpg"
            alt="Studio interior"
            className="parallax-image w-full h-full object-cover scale-110"
          />
        </div>

        {/* Text Card */}
        <div
          ref={textCardRef}
          className="absolute left-[70vw] top-[36vh] w-[24vw] h-[54vh] text-card flex flex-col justify-between p-6"
        >
          <div>
            <span
              ref={pillRef}
              className="inline-block px-3 py-1.5 bg-[#2F6BFF]/10 text-[#2F6BFF] text-xs font-mono uppercase tracking-wider rounded-full mb-6"
            >
              Open for projects
            </span>
            <p className="text-[#0B0D10] text-sm leading-relaxed">
              We design identities, campaigns, and digital experiences for teams who value restraint.
            </p>
          </div>
          <a
            href="#process"
            className="text-[#2F6BFF] text-sm font-medium hover:underline flex items-center gap-2"
          >
            Read our process
            <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 8l4 4m0 0l-4 4m4-4H3" />
            </svg>
          </a>
        </div>
      </div>
    </section>
  );
};

export default StudioSnapshot;
