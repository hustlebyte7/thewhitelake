import { useEffect, useRef } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Building2, Cpu, BarChart3, Shield } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

const metrics = [
  {
    value: 2.4,
    prefix: '$',
    suffix: 'M',
    label: 'Client cost savings delivered'
  },
  {
    value: 50,
    prefix: '',
    suffix: '+',
    label: 'AI systems deployed'
  },
  {
    value: 60,
    prefix: '',
    suffix: '%',
    label: 'Average efficiency gain'
  },
  {
    value: 24,
    prefix: '',
    suffix: '/7',
    label: 'Automated workflows running'
  }
];

const clients = [
  { icon: Building2, name: 'Enterprise' },
  { icon: Cpu, name: 'Technology' },
  { icon: BarChart3, name: 'Finance' },
  { icon: Shield, name: 'Healthcare' }
];

const Results = () => {
  const sectionRef = useRef<HTMLElement>(null);
  const headingRef = useRef<HTMLDivElement>(null);
  const metricsRef = useRef<HTMLDivElement>(null);
  const clientsRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      gsap.fromTo(headingRef.current,
        { opacity: 0, y: 30 },
        {
          opacity: 1,
          y: 0,
          duration: 0.6,
          scrollTrigger: {
            trigger: headingRef.current,
            start: 'top 80%',
            toggleActions: 'play none none reverse'
          }
        }
      );

      // Animate metric cards with count-up
      const metricCards = metricsRef.current?.querySelectorAll('.metric-card');
      metricCards?.forEach((card, i) => {
        const valueEl = card.querySelector('.metric-value');
        const targetValue = metrics[i].value;
        
        gsap.fromTo(card,
          { opacity: 0, y: 40 },
          {
            opacity: 1,
            y: 0,
            duration: 0.6,
            delay: i * 0.1,
            scrollTrigger: {
              trigger: metricsRef.current,
              start: 'top 75%',
              toggleActions: 'play none none reverse',
              onEnter: () => {
                if (valueEl) {
                  gsap.fromTo({ val: 0 },
                    { val: targetValue },
                    {
                      duration: 2,
                      ease: 'power2.out',
                      onUpdate: function() {
                        const val = this.targets()[0].val;
                        if (Number.isInteger(targetValue)) {
                          valueEl.textContent = Math.round(val).toString();
                        } else {
                          valueEl.textContent = val.toFixed(1);
                        }
                      }
                    }
                  );
                }
              }
            }
          }
        );
      });

      gsap.fromTo(clientsRef.current,
        { opacity: 0, y: 20 },
        {
          opacity: 1,
          y: 0,
          duration: 0.6,
          scrollTrigger: {
            trigger: clientsRef.current,
            start: 'top 85%',
            toggleActions: 'play none none reverse'
          }
        }
      );
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  return (
    <section
      ref={sectionRef}
      id="results"
      className="py-20 lg:py-32 bg-slate-900"
    >
      <div className="section-padding">
        <div ref={headingRef} className="text-center max-w-3xl mx-auto mb-16">
          <span className="label-mono text-blue-400 mb-4 block">Results</span>
          <h2 className="text-3xl lg:text-5xl font-bold text-white mb-4">
            Proven Outcomes, Real Impact
          </h2>
          <p className="text-lg text-slate-400">
            Numbers that speak to the value we deliver.
          </p>
        </div>

        {/* Metrics Grid */}
        <div
          ref={metricsRef}
          className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6 max-w-5xl mx-auto mb-16"
        >
          {metrics.map((metric, i) => (
            <div
              key={i}
              className="metric-card bg-slate-800 rounded-2xl p-6 lg:p-8 text-center border border-slate-700"
            >
              <div className="text-4xl lg:text-5xl font-bold text-white mb-2">
                <span className="metric-value">{metric.prefix}{metric.value}</span>
                <span className="text-blue-400">{metric.suffix}</span>
              </div>
              <p className="text-slate-400 text-sm">{metric.label}</p>
            </div>
          ))}
        </div>

        {/* Client Types */}
        <div ref={clientsRef} className="text-center">
          <p className="label-mono text-slate-500 mb-6">Industries We Serve</p>
          <div className="flex flex-wrap justify-center gap-6">
            {clients.map((client) => (
              <div
                key={client.name}
                className="flex items-center gap-3 px-5 py-3 bg-slate-800 rounded-full border border-slate-700"
              >
                <client.icon className="w-5 h-5 text-blue-400" />
                <span className="text-slate-300 font-medium">{client.name}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default Results;
