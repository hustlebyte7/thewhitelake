import { useEffect } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import Navigation from './sections/Navigation';
import Hero from './sections/Hero';
import ProblemSolution from './sections/ProblemSolution';
import Services from './sections/Services';
import HowItWorks from './sections/HowItWorks';
import Results from './sections/Results';
import CaseStudies from './sections/CaseStudies';
import About from './sections/About';
import Testimonials from './sections/Testimonials';
import CTABanner from './sections/CTABanner';
import Contact from './sections/Contact';
import Footer from './sections/Footer';
import './App.css';

gsap.registerPlugin(ScrollTrigger);

function App() {
  useEffect(() => {
    // Refresh ScrollTrigger on load
    ScrollTrigger.refresh();
    
    return () => {
      ScrollTrigger.getAll().forEach(st => st.kill());
    };
  }, []);

  return (
    <div className="min-h-screen bg-[#FAFBFC]">
      <Navigation />
      <main>
        <Hero />
        <ProblemSolution />
        <Services />
        <HowItWorks />
        <Results />
        <CaseStudies />
        <About />
        <Testimonials />
        <CTABanner />
        <Contact />
      </main>
      <Footer />
    </div>
  );
}

export default App;
